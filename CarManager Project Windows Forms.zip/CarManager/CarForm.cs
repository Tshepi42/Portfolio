﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarManager
{
    public partial class CarForm : Form
    {
        private BindingList<CCar> cars;
        public CarForm()
        {
            InitializeComponent();
            cars = new BindingList<CCar>();
            lstCars.DataSource = cars;
           
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string make = txtMake.Text.Trim();
            string model = txtModel.Text.Trim();
            string colour = txtColour.Text.Trim();
            int year = (int)nudYear.Value;

            if (string.IsNullOrEmpty(make) || string.IsNullOrEmpty(model) || string.IsNullOrEmpty(colour))
            {
                MessageBox.Show("Ensure all datafields are completed", "Error", MessageBoxButtons.OK);
                return;
            }

            
            CCar newCar = new CCar(make, model, colour, year);

            
            cars.Add(newCar);

           
            txtMake.Clear();
            txtModel.Clear();
            txtColour.Clear();
            nudYear.Value = 2000;

        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (lstCars.SelectedItem != null)
            {
                cars.Remove((CCar)lstCars.SelectedItem);
            }
            else
            {
                MessageBox.Show("Please select a car to remove.", "Selection Error", MessageBoxButtons.OK);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Are you sure you want to clear the list?", "Confirmation", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                cars.Clear();
            }
        }
    }
}
