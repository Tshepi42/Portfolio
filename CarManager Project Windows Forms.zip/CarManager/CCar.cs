﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarManager
{
    class CCar
    {
        private string sMake;
        private string sModel;

        public string Make
        {
            get { return sMake; }
            set { sMake = value; }
        }

        public string Model
        {
            get { return sModel; }
            set { sModel = value; }
        }
        public string Colour { get; set; }
        public int Year { get; set; }

        public CCar(string Make, string Model, string Colour, int Year)
        {
            this.Make = Make;
            this.Model = Model;
            this.Colour = Colour;
            this.Year = Year;
        }

        public override string ToString()
        {
            return $"Make: {Make}, Model: {Model}, Colour: {Colour}, Year: {Year}";
        }
    }
}
