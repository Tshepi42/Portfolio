﻿/*Tshepiso Moela
 * 2020163321
 * Practical 8
 * 2 May 2024
 */
using System;

namespace BMWBuilder
{
    class Program
    {
        static void Main(string[] args)
        {
            int iOption = 0;
            do
            {
                Console.Clear();

                string sQuery = "";
                DisplayTypes();

                Console.Write("Select a starting type: ");

                if (CheckValidInput(out iOption) && iOption != -1)
                {
                    switch (iOption)
                    {
                        case 1:
                            BuildCustomOrder("Sedan", ref sQuery);
                            DisplayBuild(ref sQuery);
                            break;
                        case 2:
                            BuildCustomOrder("SUV", ref sQuery);
                            DisplayBuild(ref sQuery);
                            break;
                        case 3:
                            BuildCustomOrder("Truck", ref sQuery);
                            DisplayBuild(ref sQuery);
                            break;
                        default:
                            Console.WriteLine("\nThat is not a valid option,press any key to try again...");
                            Console.ReadKey();
                            break;
                    }

                }

            } while (iOption != -1);
            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }//Main End

        //1. CheckValidInput method
        static bool CheckValidInput(out int result)
        {
            string input = Console.ReadLine();
            return int.TryParse(input, out result);
        }

        //2. GetColour method
        static string GetColour()
        {
            Console.Write("What colour should your BMW be? ");
            return Console.ReadLine();
        }
        //3. AddLeatherSeats method
       
        public static void AddLeatherSeats(ref string seats)
        {
            Console.Write("Would you like to add leather seats to your BMW? (Y/N): ");
            if (Console.ReadLine().ToUpper() == "Y")
            {
                string s = " with added leather seats.";
            }
            else
            {
                string s = " without added leather seats.";
            }
        }//AddLeatherSeats end

        //4. BuildCustomOrder
        static void BuildCustomOrder(string DisplayType, ref string seats)
        {
            string colour = GetColour();
            AddLeatherSeats(ref seats);
            Console.WriteLine("You have selected a " + colour + " BMW " + DisplayType + seats );
        }

        //5. DisplayBuild
        public static void DisplayBuild(ref string build)
        {
            Console.WriteLine("\n---------------------------THANK YOU-----------------------------");
            Console.WriteLine("We will contact you soon to discuss the price and payment options.\nPress any key to continue....");
            Console.ReadKey();
        }//DisplayBuild end


        public static void DisplayTypes()
        {
            Console.WriteLine("----------------------Welcome to the BMW Dealership!----------------------");
            Console.WriteLine("Please provide us with some details regarding the BMW you're interested in.\n");
            Console.WriteLine("----------------------------------TYPES-----------------------------------");
            Console.WriteLine("1) Sedan");
            Console.WriteLine("2) SUV");
            Console.WriteLine("3) Truck");
            Console.WriteLine("-1) Cancel build and close system\n");
        }//DisplayTypes end

    }//Class end

}//Namespace end