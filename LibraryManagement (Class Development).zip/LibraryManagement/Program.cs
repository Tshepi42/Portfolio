﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManagement
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create a Library
            Library mylibrary = new Library();

            // Create some Book objects
            Book book1 = new Book("1984", "George Orwell", "123456789");
            Book book2 = new Book("To Kill a Mockingbird", "Harper Lee", "987654321");
            Book book3 = new Book("The Great Gatsby", "F. Scott Fitzgerald", "192837465");
            Book book4 = new Book("Man's Search for Meaning", "Viktor E. Frankl", "135792468");

            // Add books to the library
            Console.WriteLine("Adding Books:");
            mylibrary.AddBook(book1);
            mylibrary.AddBook(book2);
            mylibrary.AddBook(book3);
            mylibrary.AddBook(book4);

            // Display all books
            mylibrary.GetAllBooks();

            // Find a book by title
            Book foundBook = mylibrary.FindBookByTitle("1984");
            if (foundBook != null)
            {
                Console.WriteLine("\nFound Book: \n" + foundBook.GetBookInfo());
            }

            // Check out a book
            Console.WriteLine("\nJohn attempt to check out 1984:");
            foundBook.CheckOut("John");

            // Try to check out the same book again
            Console.WriteLine("\nSarah attempt to check out 1984:");
            foundBook.CheckOut("Sarah");

            // Return the book
            Console.WriteLine("\nJohn returns the book:");
            foundBook.Return();

            // Remove a book from the library by ISBN
            Console.WriteLine("\nRemoving a book using the ISBN:");
            mylibrary.RemoveBook("987654321");

            // Attempt to remove a book from the library by ISBN that doesn't exist
            Console.WriteLine("\nAttempting to remove the same book again:");
            mylibrary.RemoveBook("987654321");

            // Display all books again
            mylibrary.GetAllBooks();

            Console.ReadKey();
        }
    }
}
