﻿/*Tshepiso Moela
 * 2020163321
 * Practical 7
 * 9 September 2024
 */
using System;


namespace LibraryManagement
{
    class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public string ISBN { get; set; }
        public bool IsCheckedOut { get; private set; }
        public string CheckedOutTo { get; private set; }

        public Book(string title, string author, string isbn)
        {
            Title = title;
            Author = author;
            ISBN = isbn;
            IsCheckedOut = false;
            CheckedOutTo = "";
        }

        public void CheckOut(string sName)
        {
            if (!IsCheckedOut)
            {
                IsCheckedOut = true;
                CheckedOutTo = sName;
                Console.WriteLine($"'{Title}' has been checked out.");
            }
            else
            {
                Console.WriteLine($"'{Title}' is already checked out by {CheckedOutTo}.");
            }
        }

        public void Return()
        {
            if (IsCheckedOut)
            {
                IsCheckedOut = false;
                Console.WriteLine($"{CheckedOutTo} has returned '{Title}'.");
                CheckedOutTo = "";
            }
            else
            {
                Console.WriteLine($"'{Title}' was not checked out.");
            }
        }

        public string GetBookInfo()
        {
            return $"Title: {Title}, Author: {Author}, ISBN: {ISBN}, Checked Out: {IsCheckedOut}";
        }
    }
}
