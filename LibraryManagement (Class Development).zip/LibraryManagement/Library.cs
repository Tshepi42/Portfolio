﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManagement
{
    class Library
    {
        private List<Book> books { get; set;} //Public property that hold a list of books in the library

        public Library()
        {
            books = new List<Book>();
        }

        public Library(List<Book> initialBooks)
        {
            books = new List<Book>(initialBooks);
        }
        public void AddBook(Book book)
        {
            books.Add(book);
        }

        public void RemoveBook(string isbn)
        {
            Book bookToRemove = books.FirstOrDefault(b => b.ISBN == isbn);

            if (bookToRemove != null)
            {
                books.Remove(bookToRemove);
                Console.WriteLine($"'{bookToRemove.Title}' has been removed from the library.");
            }
            else
            {
                Console.WriteLine($"Book with  ISBN {isbn} not found.");
            }
        }

        public Book FindBookByTitle(string title)
        {
            return books.FirstOrDefault(b => b.Title.Equals(title, StringComparison.OrdinalIgnoreCase));
        }

        public void GetAllBooks()
        {
            foreach (Book book in books)
            {
                Console.WriteLine(book.GetBookInfo()); // Assuming Book class has a DisplayInfo method
            }
        }
    }
}
